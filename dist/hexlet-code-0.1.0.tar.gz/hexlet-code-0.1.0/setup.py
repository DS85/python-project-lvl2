# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0', 'argparse>=1.4.0,<2.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'DS85',
    'author_email': 'dimon85@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8',
}


setup(**setup_kwargs)
