#!/usr/bin/env python

import argparse
from gendiff.parser import parser


def main():
    parser()


if __name__ == '__main__':
    main()
